-- ============================================================
--  FLUXO VITAL — 11. CAMPANHAS e INSCRICOES_CAMPANHA
--
--  Agora COM entidade Java: model/Campanha.java e
--  model/InscricaoCampanha.java, com repository e endpoints
--  em InstituicaoController (gerenciar) e DoadorController
--  (ver campanhas publicadas / se inscrever).
--
--  ⚠️  Se você já rodou o antigo 07_legado_campanhas_doacoes.sql,
--      este arquivo SUBSTITUI a tabela `campanhas` antiga (dropa
--      e recria com as colunas usadas pela entidade Java).
--      A tabela `doacoes_recebidas` do arquivo 07 não é afetada
--      e continua existindo (sem uso pela aplicação).
--
--  Requer 01_schema_doador.sql e 05_schema_instituicao.sql
--  já executados.
-- ============================================================

USE fluxovital;

DROP TABLE IF EXISTS inscricoes_campanha;
DROP TABLE IF EXISTS campanhas;

CREATE TABLE campanhas (
  id               BIGINT        AUTO_INCREMENT PRIMARY KEY,
  id_instituicao   BIGINT        NOT NULL,
  titulo           VARCHAR(200)  NOT NULL,
  descricao        TEXT          DEFAULT NULL,
  tipo_doacao      ENUM('sangue','medula','leite','todos') NOT NULL DEFAULT 'todos',
  data_inicio      DATE          NOT NULL,
  data_fim         DATE          DEFAULT NULL,
  meta_inscricoes  INT           DEFAULT NULL,
  status           ENUM('rascunho','publicada','encerrada') NOT NULL DEFAULT 'rascunho',
  criado_em        DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  CONSTRAINT fk_campanha_instituicao
    FOREIGN KEY (id_instituicao) REFERENCES instituicoes(id)
    ON DELETE CASCADE
);

CREATE TABLE inscricoes_campanha (
  id             BIGINT     AUTO_INCREMENT PRIMARY KEY,
  id_campanha    BIGINT     NOT NULL,
  id_doador      BIGINT     NOT NULL,
  status         ENUM('inscrito','cancelado') NOT NULL DEFAULT 'inscrito',
  inscrito_em    DATETIME   NOT NULL DEFAULT CURRENT_TIMESTAMP,
  cancelado_em   DATETIME   DEFAULT NULL,

  CONSTRAINT fk_inscricao_campanha
    FOREIGN KEY (id_campanha) REFERENCES campanhas(id)
    ON DELETE CASCADE,

  CONSTRAINT fk_inscricao_doador
    FOREIGN KEY (id_doador) REFERENCES doador(id)
    ON DELETE CASCADE,

  CONSTRAINT uq_campanha_doador UNIQUE (id_campanha, id_doador)
);

-- ─── Consultas de referência ────────────────────────────────────

-- Campanhas publicadas (as que aparecem no painel do doador)
SELECT c.id, i.nome AS instituicao, c.titulo, c.tipo_doacao,
       c.data_inicio, c.data_fim
FROM campanhas c
JOIN instituicoes i ON i.id = c.id_instituicao
WHERE c.status = 'publicada'
ORDER BY c.data_inicio;

-- Quem se inscreveu em uma campanha específica (trocar o id)
SELECT ic.id, d.nome AS doador, d.email, d.telefone,
       ic.status, ic.inscrito_em
FROM inscricoes_campanha ic
JOIN doador d ON d.id = ic.id_doador
WHERE ic.id_campanha = 1
ORDER BY ic.inscrito_em DESC;
