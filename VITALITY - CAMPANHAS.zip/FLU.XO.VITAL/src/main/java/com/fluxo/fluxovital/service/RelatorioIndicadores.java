package com.fluxo.fluxovital.service;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * DTO com todos os indicadores do relatório executivo.
 * Usado tanto para alimentar a página /relatorios quanto para gerar
 * os arquivos exportados (Excel/CSV), garantindo que a tela e o arquivo
 * baixado sempre mostrem exatamente os mesmos números.
 */
public class RelatorioIndicadores {

    // ─── Totais gerais ──────────────────────────────────────────────────────
    public long totalSangue;
    public long totalMedula;
    public long totalLeite;
    public long totalInstituicoes;
    public long totalGeral;          // sangue + medula + leite
    public long totalRealizadas;     // realizadas nos 3 tipos

    // ─── Indicadores de desempenho ──────────────────────────────────────────
    public double taxaConversao;     // % realizados / total geral
    public double taxaCancelamento;  // % cancelados / total geral
    public double taxaPendencia;     // % pendentes / total geral

    // ─── Contagem por status, agregada nos 3 tipos de doação ───────────────
    // chave: pendente | confirmado | cancelado | realizado
    public Map<String, Long> statusGeral = new LinkedHashMap<>();

    // ─── Contagem por status, detalhada por tipo ───────────────────────────
    public Map<String, Long> statusSangue = new LinkedHashMap<>();
    public Map<String, Long> statusMedula = new LinkedHashMap<>();
    public Map<String, Long> statusLeite  = new LinkedHashMap<>();

    // ─── Instituições ───────────────────────────────────────────────────────
    public Map<String, Long> instituicoesPorCategoria = new LinkedHashMap<>();
    public List<EstadoContagem> instituicoesPorEstado;

    // ─── Evolução mensal (últimos 6 meses) ─────────────────────────────────
    public List<MesContagem> evolucaoMensal;

    public String geradoEm; // data/hora de geração, formatada, para exibir no relatório

    public static class EstadoContagem {
        public String estado;
        public long total;
        public EstadoContagem(String estado, long total) { this.estado = estado; this.total = total; }
    }

    public static class MesContagem {
        public String mes;      // ex: "Mar/2026"
        public long sangue;
        public long medula;
        public long leite;
        public long total;
        public MesContagem(String mes, long sangue, long medula, long leite) {
            this.mes = mes;
            this.sangue = sangue;
            this.medula = medula;
            this.leite = leite;
            this.total = sangue + medula + leite;
        }
    }
}
