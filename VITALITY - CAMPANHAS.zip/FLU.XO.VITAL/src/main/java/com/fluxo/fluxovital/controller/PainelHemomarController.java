package com.fluxo.fluxovital.controller;

import com.fluxo.fluxovital.model.DoadorSangue;
import com.fluxo.fluxovital.repository.DoadorSangueRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.text.Normalizer;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Random;

/**
 * Painel Hemomar — indicadores, acompanhamento (próximos agendamentos) e
 * lista de participantes das doações de SANGUE agendadas para a unidade
 * Hemomar (São Luís - Sede).
 * <p>
 * A unidade "hemomar_sao_luis" é o valor fixo usado no &lt;select id="unidade"&gt;
 * do formulário de doação de sangue (ver doador/sangue/form.html). Como esse
 * valor não é uma FK pra tabela de instituições, filtramos direto pelo campo
 * "unidade" da doação.
 */
@Controller
public class PainelHemomarController {

    private static final String UNIDADE_HEMOMAR = "hemomar_sao_luis";
    private static final int SIMULACAO_MIN = 1;
    private static final int SIMULACAO_MAX = 50;

    private final DoadorSangueRepository doadorSangueRepository;

    public PainelHemomarController(DoadorSangueRepository doadorSangueRepository) {
        this.doadorSangueRepository = doadorSangueRepository;
    }

    /** DTO simples pra listar os participantes na tela. */
    public static class Participante {
        private final Long id;
        private final String nome;
        private final String telefone;
        private final String email;
        private final LocalDate data;
        private final String turno;
        private final String status;
        private final LocalDateTime criadoEm;
        private final String linkDetalhes;
        private final boolean simulado;

        public Participante(Long id, String nome, String telefone, String email,
                             LocalDate data, String turno, String status,
                             LocalDateTime criadoEm, String linkDetalhes, boolean simulado) {
            this.id = id;
            this.nome = nome;
            this.telefone = telefone;
            this.email = email;
            this.data = data;
            this.turno = turno;
            this.status = status;
            this.criadoEm = criadoEm;
            this.linkDetalhes = linkDetalhes;
            this.simulado = simulado;
        }

        public Long getId() { return id; }
        public String getNome() { return nome; }
        public String getTelefone() { return telefone; }
        public String getEmail() { return email; }
        public LocalDate getData() { return data; }
        public String getTurno() { return turno; }
        public String getStatus() { return status; }
        public LocalDateTime getCriadoEm() { return criadoEm; }
        public String getLinkDetalhes() { return linkDetalhes; }
        public boolean isSimulado() { return simulado; }
    }

    @GetMapping("/instituicao/painel-hemomar")
    public String painelHemomar(HttpSession session, Model model) {
        if (session.getAttribute("instituicao_id") == null) {
            return "redirect:/instituicao/categoria";
        }

        List<DoadorSangue> sangue = doadorSangueRepository.findByUnidadeOrderByDataAgendamentoAsc(UNIDADE_HEMOMAR);

        // ── Indicadores ─────────────────────────────────────────────────────
        long totalParticipantes = sangue.size();
        long pendentes   = sangue.stream().filter(s -> s.getStatus() == DoadorSangue.StatusTriagem.pendente).count();
        long confirmados = sangue.stream().filter(s -> s.getStatus() == DoadorSangue.StatusTriagem.confirmado).count();
        long realizados  = sangue.stream().filter(s -> s.getStatus() == DoadorSangue.StatusTriagem.realizado).count();
        long cancelados  = sangue.stream().filter(s -> s.getStatus() == DoadorSangue.StatusTriagem.cancelado).count();

        long finalizados = realizados + cancelados;
        double taxaComparecimento = finalizados == 0 ? 0.0 : (realizados * 100.0 / finalizados);

        model.addAttribute("totalParticipantes", totalParticipantes);
        model.addAttribute("pendentes", pendentes);
        model.addAttribute("confirmados", confirmados);
        model.addAttribute("realizados", realizados);
        model.addAttribute("cancelados", cancelados);
        model.addAttribute("taxaComparecimento", Math.round(taxaComparecimento * 10.0) / 10.0);

        long simuladosAtivos = sangue.stream().filter(s -> Boolean.TRUE.equals(s.getSimulado())).count();
        model.addAttribute("simuladosAtivos", simuladosAtivos);

        // ── Participantes (mais recentes primeiro) ──────────────────────────
        List<Participante> participantes = new ArrayList<>();
        for (DoadorSangue s : sangue) {
            participantes.add(new Participante(s.getId(), s.getNome(), s.getTelefone(), s.getEmail(),
                    s.getDataAgendamento(), s.getTurno() != null ? s.getTurno().name() : null,
                    s.getStatus().name(), s.getCriadoEm(), "/instituicao/doacoes/" + s.getId(),
                    Boolean.TRUE.equals(s.getSimulado())));
        }
        participantes.sort(Comparator.comparing(Participante::getCriadoEm,
                Comparator.nullsLast(Comparator.reverseOrder())));
        model.addAttribute("participantes", participantes);

        // ── Acompanhamento: próximos agendamentos em aberto (data >= hoje) ──
        LocalDate hoje = LocalDate.now();
        List<Participante> proximos = new ArrayList<>();
        for (Participante p : participantes) {
            boolean emAberto = "pendente".equals(p.getStatus()) || "confirmado".equals(p.getStatus());
            if (emAberto && p.getData() != null && !p.getData().isBefore(hoje)) {
                proximos.add(p);
            }
        }
        proximos.sort(Comparator.comparing(Participante::getData, Comparator.nullsLast(Comparator.naturalOrder())));
        model.addAttribute("proximosAgendamentos", proximos);

        return "instituicao/painel_hemomar";
    }

    // ── Simulador: gera participantes fictícios pra testar/demonstrar o painel ──
    @PostMapping("/instituicao/painel-hemomar/simular")
    public String simular(@RequestParam(defaultValue = "10") int quantidade,
                           HttpSession session,
                           RedirectAttributes redirectAttributes) {
        if (session.getAttribute("instituicao_id") == null) {
            return "redirect:/instituicao/categoria";
        }

        int qtd = Math.max(SIMULACAO_MIN, Math.min(SIMULACAO_MAX, quantidade));
        Random rnd = new Random();

        List<DoadorSangue> gerados = new ArrayList<>();
        for (int i = 0; i < qtd; i++) {
            gerados.add(gerarParticipanteFicticio(rnd));
        }
        doadorSangueRepository.saveAll(gerados);

        redirectAttributes.addFlashAttribute("sucesso",
                qtd + " participante(s) simulado(s) gerado(s) com sucesso.");
        return "redirect:/instituicao/painel-hemomar";
    }

    @PostMapping("/instituicao/painel-hemomar/limpar-simulados")
    public String limparSimulados(HttpSession session, RedirectAttributes redirectAttributes) {
        if (session.getAttribute("instituicao_id") == null) {
            return "redirect:/instituicao/categoria";
        }

        long removidos = doadorSangueRepository.deleteByUnidadeAndSimuladoTrue(UNIDADE_HEMOMAR);
        redirectAttributes.addFlashAttribute("sucesso",
                removidos > 0 ? removidos + " registro(s) simulado(s) removido(s)."
                              : "Não havia dados simulados para remover.");
        return "redirect:/instituicao/painel-hemomar";
    }

    private static final String[] NOMES = {
        "Ana", "Bruno", "Carla", "Diego", "Eduarda", "Felipe", "Gabriela", "Hugo",
        "Isabela", "Joao", "Karina", "Lucas", "Marina", "Nicolas", "Olivia", "Pedro",
        "Rafael", "Sabrina", "Thiago", "Valentina", "Wesley", "Yasmin", "Vitor",
        "Camila", "Rodrigo", "Beatriz", "Gustavo", "Larissa", "Mateus", "Fernanda"
    };
    private static final String[] SOBRENOMES = {
        "Silva", "Santos", "Oliveira", "Souza", "Rodrigues", "Ferreira", "Alves",
        "Pereira", "Lima", "Gomes", "Costa", "Ribeiro", "Martins", "Carvalho",
        "Almeida", "Lopes", "Soares", "Fernandes", "Vieira", "Barbosa"
    };
    private static final String[] TIPOS_SANGUINEOS = {"A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"};
    private static final String[] CANAIS = {
        "Instagram", "Indicacao de amigo", "Campanha na faculdade", "Panfleto", "Site da instituicao"
    };
    private static final DoadorSangue.StatusTriagem[] STATUS_POOL = {
        DoadorSangue.StatusTriagem.pendente, DoadorSangue.StatusTriagem.pendente,
        DoadorSangue.StatusTriagem.pendente,
        DoadorSangue.StatusTriagem.confirmado, DoadorSangue.StatusTriagem.confirmado,
        DoadorSangue.StatusTriagem.realizado, DoadorSangue.StatusTriagem.realizado,
        DoadorSangue.StatusTriagem.realizado,
        DoadorSangue.StatusTriagem.cancelado
    };

    private DoadorSangue gerarParticipanteFicticio(Random rnd) {
        String primeiroNome = NOMES[rnd.nextInt(NOMES.length)];
        String sobrenome = SOBRENOMES[rnd.nextInt(SOBRENOMES.length)];
        String nomeCompleto = primeiroNome + " " + sobrenome;
        DoadorSangue.StatusTriagem status = STATUS_POOL[rnd.nextInt(STATUS_POOL.length)];

        DoadorSangue ds = new DoadorSangue();
        ds.setNome(nomeCompleto);
        ds.setCpf("999" + String.format("%08d", rnd.nextInt(100_000_000)));
        ds.setRg("9" + String.format("%07d", rnd.nextInt(10_000_000)));
        ds.setNascimento(LocalDate.now().minusYears(18 + rnd.nextInt(43)).minusDays(rnd.nextInt(365)));
        ds.setSexo(rnd.nextBoolean() ? DoadorSangue.Sexo.masculino : DoadorSangue.Sexo.feminino);
        ds.setPeso(50 + rnd.nextInt(51) + rnd.nextDouble());
        ds.setAltura(1.50 + rnd.nextInt(46) / 100.0);
        ds.setEmail(semAcento(primeiroNome).toLowerCase() + "." + semAcento(sobrenome).toLowerCase()
                + rnd.nextInt(100) + "@exemplo.com");
        ds.setTelefone(String.format("(98) 9%04d-%04d", rnd.nextInt(10000), rnd.nextInt(10000)));
        ds.setEndereco("Rua Simulada, " + (rnd.nextInt(900) + 1) + ", Sao Luis - MA");
        ds.setTipoSanguineo(TIPOS_SANGUINEOS[rnd.nextInt(TIPOS_SANGUINEOS.length)]);
        ds.setHistoricoDoacao(DoadorSangue.HistoricoDoacao.values()[rnd.nextInt(3)]);
        ds.setInteresseDoador(true);
        ds.setCondicaoSaude(false);
        ds.setUnidade(UNIDADE_HEMOMAR);
        ds.setTurno(rnd.nextBoolean() ? DoadorSangue.Turno.manha : DoadorSangue.Turno.tarde);
        ds.setComoSoube(CANAIS[rnd.nextInt(CANAIS.length)]);
        ds.setConsentimento(true);
        ds.setStatus(status);
        ds.setSimulado(true);

        boolean emAberto = status == DoadorSangue.StatusTriagem.pendente
                || status == DoadorSangue.StatusTriagem.confirmado;
        ds.setDataAgendamento(emAberto
                ? LocalDate.now().plusDays(1 + rnd.nextInt(20))
                : LocalDate.now().minusDays(1 + rnd.nextInt(60)));

        return ds;
    }

    private static String semAcento(String texto) {
        return Normalizer.normalize(texto, Normalizer.Form.NFD).replaceAll("\\p{M}", "");
    }
}
