package com.fluxo.fluxovital.repository;

import com.fluxo.fluxovital.model.InscricaoCampanha;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface InscricaoCampanhaRepository extends JpaRepository<InscricaoCampanha, Long> {

    // ─── Lado da instituição: quem se inscreveu numa campanha ───────────────
    List<InscricaoCampanha> findByCampanhaIdOrderByInscritoEmDesc(Long campanhaId);

    // ─── Lado do doador: minhas inscrições ───────────────────────────────────
    List<InscricaoCampanha> findByDoadorIdOrderByInscritoEmDesc(Long doadorId);

    Optional<InscricaoCampanha> findByCampanhaIdAndDoadorId(Long campanhaId, Long doadorId);

    long countByCampanhaIdAndStatus(Long campanhaId, InscricaoCampanha.StatusInscricao status);
}
