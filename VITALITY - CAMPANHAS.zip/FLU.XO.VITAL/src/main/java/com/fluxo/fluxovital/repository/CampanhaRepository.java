package com.fluxo.fluxovital.repository;

import com.fluxo.fluxovital.model.Campanha;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface CampanhaRepository extends JpaRepository<Campanha, Long> {

    // ─── Painel da instituição ──────────────────────────────────────────────
    List<Campanha> findByInstituicaoIdOrderByCriadoEmDesc(Long instituicaoId);
    Optional<Campanha> findByIdAndInstituicaoId(Long id, Long instituicaoId);

    // ─── Painel do doador (só campanhas publicadas) ─────────────────────────
    List<Campanha> findByStatusOrderByDataInicioAsc(Campanha.StatusCampanha status);
}
