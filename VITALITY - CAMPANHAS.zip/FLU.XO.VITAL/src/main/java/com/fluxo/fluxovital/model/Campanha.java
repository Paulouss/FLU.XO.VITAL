package com.fluxo.fluxovital.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "campanhas")
public class Campanha {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_instituicao", nullable = false)
    private Instituicao instituicao;

    @Column(name = "titulo", nullable = false, length = 200)
    private String titulo;

    @Column(name = "descricao", length = 2000)
    private String descricao;

    @Enumerated(EnumType.STRING)
    @Column(name = "tipo_doacao", nullable = false)
    private TipoDoacaoCampanha tipoDoacao = TipoDoacaoCampanha.todos;

    @Column(name = "data_inicio", nullable = false)
    private LocalDate dataInicio;

    @Column(name = "data_fim")
    private LocalDate dataFim;

    @Column(name = "meta_inscricoes")
    private Integer metaInscricoes;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false)
    private StatusCampanha status = StatusCampanha.rascunho;

    @Column(name = "criado_em")
    private LocalDateTime criadoEm;

    @Column(name = "atualizado_em")
    private LocalDateTime atualizadoEm;

    @PrePersist
    public void prePersist() {
        LocalDateTime agora = LocalDateTime.now();
        this.criadoEm = agora;
        this.atualizadoEm = agora;
        if (this.status == null) {
            this.status = StatusCampanha.rascunho;
        }
    }

    @PreUpdate
    public void preUpdate() {
        this.atualizadoEm = LocalDateTime.now();
    }

    public enum TipoDoacaoCampanha { sangue, medula, leite, todos }

    public enum StatusCampanha { rascunho, publicada, encerrada }

    public Campanha() {}

    // --- GETTERS E SETTERS ---

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Instituicao getInstituicao() { return instituicao; }
    public void setInstituicao(Instituicao instituicao) { this.instituicao = instituicao; }

    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }

    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) { this.descricao = descricao; }

    public TipoDoacaoCampanha getTipoDoacao() { return tipoDoacao; }
    public void setTipoDoacao(TipoDoacaoCampanha tipoDoacao) { this.tipoDoacao = tipoDoacao; }

    public LocalDate getDataInicio() { return dataInicio; }
    public void setDataInicio(LocalDate dataInicio) { this.dataInicio = dataInicio; }

    public LocalDate getDataFim() { return dataFim; }
    public void setDataFim(LocalDate dataFim) { this.dataFim = dataFim; }

    public Integer getMetaInscricoes() { return metaInscricoes; }
    public void setMetaInscricoes(Integer metaInscricoes) { this.metaInscricoes = metaInscricoes; }

    public StatusCampanha getStatus() { return status; }
    public void setStatus(StatusCampanha status) { this.status = status; }

    public LocalDateTime getCriadoEm() { return criadoEm; }
    public void setCriadoEm(LocalDateTime criadoEm) { this.criadoEm = criadoEm; }

    public LocalDateTime getAtualizadoEm() { return atualizadoEm; }
    public void setAtualizadoEm(LocalDateTime atualizadoEm) { this.atualizadoEm = atualizadoEm; }

    // Auxiliar pra usar diretamente no Thymeleaf (campanha.encerrada, campanha.editavel etc.)
    @Transient
    public boolean isEditavel() {
        return status == StatusCampanha.rascunho;
    }
}
