package com.fluxo.fluxovital.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "inscricoes_campanha",
       uniqueConstraints = @UniqueConstraint(name = "uq_campanha_doador", columnNames = {"id_campanha", "id_doador"}))
public class InscricaoCampanha {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_campanha", nullable = false)
    private Campanha campanha;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_doador", nullable = false)
    private Doador doador;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false)
    private StatusInscricao status = StatusInscricao.inscrito;

    @Column(name = "inscrito_em")
    private LocalDateTime inscritoEm;

    @Column(name = "cancelado_em")
    private LocalDateTime canceladoEm;

    @PrePersist
    public void prePersist() {
        if (this.inscritoEm == null) {
            this.inscritoEm = LocalDateTime.now();
        }
        if (this.status == null) {
            this.status = StatusInscricao.inscrito;
        }
    }

    public enum StatusInscricao { inscrito, cancelado }

    public InscricaoCampanha() {}

    // --- GETTERS E SETTERS ---

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Campanha getCampanha() { return campanha; }
    public void setCampanha(Campanha campanha) { this.campanha = campanha; }

    public Doador getDoador() { return doador; }
    public void setDoador(Doador doador) { this.doador = doador; }

    public StatusInscricao getStatus() { return status; }
    public void setStatus(StatusInscricao status) { this.status = status; }

    public LocalDateTime getInscritoEm() { return inscritoEm; }
    public void setInscritoEm(LocalDateTime inscritoEm) { this.inscritoEm = inscritoEm; }

    public LocalDateTime getCanceladoEm() { return canceladoEm; }
    public void setCanceladoEm(LocalDateTime canceladoEm) { this.canceladoEm = canceladoEm; }
}
