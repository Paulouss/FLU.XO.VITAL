package com.fluxo.fluxovital.service;

import com.fluxo.fluxovital.model.*;
import com.fluxo.fluxovital.repository.DoadorMedulaRepository;
import com.fluxo.fluxovital.repository.DoadorSangueRepository;
import com.fluxo.fluxovital.repository.DoadoraLeiteRepository;
import com.fluxo.fluxovital.repository.InstituicaoRepository;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Centraliza o cálculo dos indicadores do relatório executivo e a geração
 * dos arquivos exportáveis (Excel e CSV). A mesma lógica de agregação é
 * reaproveitada pela página /relatorios e pelos endpoints de exportação,
 * então tela e arquivo baixado nunca ficam dessincronizados.
 */
@Service
public class RelatorioService {

    private static final DateTimeFormatter DATA_HORA = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
    private static final Locale PT_BR = new Locale("pt", "BR");

    private final DoadorSangueRepository doadorSangueRepository;
    private final DoadoraLeiteRepository doadoraLeiteRepository;
    private final DoadorMedulaRepository doadorMedulaRepository;
    private final InstituicaoRepository instituicaoRepository;

    public RelatorioService(DoadorSangueRepository doadorSangueRepository,
                             DoadoraLeiteRepository doadoraLeiteRepository,
                             DoadorMedulaRepository doadorMedulaRepository,
                             InstituicaoRepository instituicaoRepository) {
        this.doadorSangueRepository = doadorSangueRepository;
        this.doadoraLeiteRepository = doadoraLeiteRepository;
        this.doadorMedulaRepository = doadorMedulaRepository;
        this.instituicaoRepository = instituicaoRepository;
    }

    /** Calcula todos os indicadores do relatório executivo a partir dos dados atuais do banco. */
    public RelatorioIndicadores calcularIndicadores() {
        List<DoadorSangue> sangue = doadorSangueRepository.findAllByOrderByCriadoEmDesc();
        List<DoadorMedula> medula = doadorMedulaRepository.findAllByOrderByCriadoEmDesc();
        List<DoadoraLeite> leite  = doadoraLeiteRepository.findAllByOrderByCriadoEmDesc();
        List<Instituicao> instituicoes = instituicaoRepository.findAllByOrderByNomeAsc();

        RelatorioIndicadores r = new RelatorioIndicadores();
        r.geradoEm = LocalDateTime.now().format(DATA_HORA);

        r.totalSangue = sangue.size();
        r.totalMedula = medula.size();
        r.totalLeite = leite.size();
        r.totalInstituicoes = instituicoes.size();
        r.totalGeral = r.totalSangue + r.totalMedula + r.totalLeite;

        // ─── Status por tipo ────────────────────────────────────────────────
        r.statusSangue = contarStatus(sangue.stream().map(s -> s.getStatus().name()).collect(Collectors.toList()));
        r.statusMedula = contarStatus(medula.stream().map(m -> m.getStatus().name()).collect(Collectors.toList()));
        r.statusLeite  = contarStatus(leite.stream().map(l -> l.getStatus().name()).collect(Collectors.toList()));

        r.statusGeral = new LinkedHashMap<>();
        for (String chave : List.of("pendente", "confirmado", "cancelado", "realizado")) {
            long soma = r.statusSangue.getOrDefault(chave, 0L)
                      + r.statusMedula.getOrDefault(chave, 0L)
                      + r.statusLeite.getOrDefault(chave, 0L);
            r.statusGeral.put(chave, soma);
        }

        r.totalRealizadas = r.statusGeral.getOrDefault("realizado", 0L);

        long cancelados = r.statusGeral.getOrDefault("cancelado", 0L);
        long pendentes  = r.statusGeral.getOrDefault("pendente", 0L);

        r.taxaConversao    = percentual(r.totalRealizadas, r.totalGeral);
        r.taxaCancelamento = percentual(cancelados, r.totalGeral);
        r.taxaPendencia    = percentual(pendentes, r.totalGeral);

        // ─── Instituições por categoria ─────────────────────────────────────
        Map<String, Long> porCategoria = new LinkedHashMap<>();
        for (CategoriaInstituicao cat : CategoriaInstituicao.values()) {
            porCategoria.put(cat.getDescricao(), 0L);
        }
        for (Instituicao i : instituicoes) {
            if (i.getCategoria() != null) {
                porCategoria.merge(i.getCategoria().getDescricao(), 1L, Long::sum);
            }
        }
        r.instituicoesPorCategoria = porCategoria;

        // ─── Instituições por estado (top 8) ────────────────────────────────
        Map<String, Long> porEstado = new LinkedHashMap<>();
        for (Instituicao i : instituicoes) {
            String estado = (i.getEstado() == null || i.getEstado().isBlank()) ? "Não informado" : i.getEstado().toUpperCase();
            porEstado.merge(estado, 1L, Long::sum);
        }
        r.instituicoesPorEstado = porEstado.entrySet().stream()
                .sorted((a, b) -> Long.compare(b.getValue(), a.getValue()))
                .limit(8)
                .map(e -> new RelatorioIndicadores.EstadoContagem(e.getKey(), e.getValue()))
                .collect(Collectors.toList());

        // ─── Evolução mensal (últimos 6 meses, com base em "criado em") ────
        YearMonth mesAtual = YearMonth.now();
        List<YearMonth> meses = new ArrayList<>();
        for (int i = 5; i >= 0; i--) meses.add(mesAtual.minusMonths(i));

        Map<YearMonth, Long> sanguePorMes = agruparPorMes(sangue.stream().map(DoadorSangue::getCriadoEm));
        Map<YearMonth, Long> medulaPorMes = agruparPorMes(medula.stream().map(DoadorMedula::getCriadoEm));
        Map<YearMonth, Long> leitePorMes  = agruparPorMes(leite.stream().map(DoadoraLeite::getCriadoEm));

        DateTimeFormatter mesFmt = DateTimeFormatter.ofPattern("MMM/yyyy", PT_BR);
        r.evolucaoMensal = meses.stream()
                .map(m -> new RelatorioIndicadores.MesContagem(
                        capitalizar(m.format(mesFmt)),
                        sanguePorMes.getOrDefault(m, 0L),
                        medulaPorMes.getOrDefault(m, 0L),
                        leitePorMes.getOrDefault(m, 0L)))
                .collect(Collectors.toList());

        return r;
    }

    private Map<YearMonth, Long> agruparPorMes(java.util.stream.Stream<LocalDateTime> datas) {
        return datas.filter(Objects::nonNull)
                .map(YearMonth::from)
                .collect(Collectors.groupingBy(m -> m, Collectors.counting()));
    }

    private Map<String, Long> contarStatus(List<String> statusList) {
        Map<String, Long> mapa = new LinkedHashMap<>();
        for (String chave : List.of("pendente", "confirmado", "cancelado", "realizado")) mapa.put(chave, 0L);
        for (String s : statusList) mapa.merge(s, 1L, Long::sum);
        return mapa;
    }

    private double percentual(long parte, long total) {
        if (total == 0) return 0.0;
        return Math.round((parte * 10000.0) / total) / 100.0;
    }

    private String capitalizar(String texto) {
        if (texto == null || texto.isEmpty()) return texto;
        return Character.toUpperCase(texto.charAt(0)) + texto.substring(1);
    }

    // ═══════════════════════════════════════════════════════════════════════
    // EXPORTAÇÃO — EXCEL (.xlsx)
    // ═══════════════════════════════════════════════════════════════════════

    public byte[] gerarExcel(RelatorioIndicadores r) throws IOException {
        try (XSSFWorkbook wb = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {

            CellStyle tituloStyle = estiloTitulo(wb);
            CellStyle cabecalhoStyle = estiloCabecalho(wb);
            CellStyle percentStyle = wb.createCellStyle();
            percentStyle.setDataFormat(wb.createDataFormat().getFormat("0.00\"%\""));

            // ── Aba 1: Resumo Geral ────────────────────────────────────────
            Sheet resumo = wb.createSheet("Resumo Geral");
            int row = 0;
            row = escreverTitulo(resumo, tituloStyle, row, "Relatório Executivo — Fluxo Vital");
            row = escreverLinha(resumo, row, "Gerado em", r.geradoEm);
            row++;

            row = escreverCabecalho(resumo, cabecalhoStyle, row, "Indicador", "Valor");
            row = escreverLinha(resumo, row, "Formulários de Sangue", r.totalSangue);
            row = escreverLinha(resumo, row, "Cadastros de Medula", r.totalMedula);
            row = escreverLinha(resumo, row, "Doações de Leite", r.totalLeite);
            row = escreverLinha(resumo, row, "Total Geral de Doações", r.totalGeral);
            row = escreverLinha(resumo, row, "Instituições Parceiras", r.totalInstituicoes);
            row = escreverLinha(resumo, row, "Doações Realizadas", r.totalRealizadas);
            row = escreverLinhaPercentual(resumo, percentStyle, row, "Taxa de Conversão (%)", r.taxaConversao);
            row = escreverLinhaPercentual(resumo, percentStyle, row, "Taxa de Cancelamento (%)", r.taxaCancelamento);
            row = escreverLinhaPercentual(resumo, percentStyle, row, "Taxa de Pendência (%)", r.taxaPendencia);
            autoAjustar(resumo, 2);

            // ── Aba 2: Status por Tipo ─────────────────────────────────────
            Sheet status = wb.createSheet("Status por Tipo");
            row = 0;
            row = escreverCabecalho(status, cabecalhoStyle, row, "Status", "Sangue", "Medula", "Leite", "Total");
            for (String chave : List.of("pendente", "confirmado", "cancelado", "realizado")) {
                long s = r.statusSangue.getOrDefault(chave, 0L);
                long m = r.statusMedula.getOrDefault(chave, 0L);
                long l = r.statusLeite.getOrDefault(chave, 0L);
                Row linha = status.createRow(row++);
                linha.createCell(0).setCellValue(capitalizar(chave));
                linha.createCell(1).setCellValue(s);
                linha.createCell(2).setCellValue(m);
                linha.createCell(3).setCellValue(l);
                linha.createCell(4).setCellValue(s + m + l);
            }
            autoAjustar(status, 5);

            // ── Aba 3: Instituições ─────────────────────────────────────────
            Sheet inst = wb.createSheet("Instituições");
            row = 0;
            row = escreverCabecalho(inst, cabecalhoStyle, row, "Categoria", "Quantidade");
            for (Map.Entry<String, Long> e : r.instituicoesPorCategoria.entrySet()) {
                row = escreverLinha(inst, row, e.getKey(), e.getValue());
            }
            row++;
            row = escreverCabecalho(inst, cabecalhoStyle, row, "Estado", "Quantidade");
            for (RelatorioIndicadores.EstadoContagem ec : r.instituicoesPorEstado) {
                row = escreverLinha(inst, row, ec.estado, ec.total);
            }
            autoAjustar(inst, 2);

            // ── Aba 4: Evolução Mensal ───────────────────────────────────────
            Sheet evolucao = wb.createSheet("Evolução Mensal");
            row = 0;
            row = escreverCabecalho(evolucao, cabecalhoStyle, row, "Mês", "Sangue", "Medula", "Leite", "Total");
            for (RelatorioIndicadores.MesContagem mc : r.evolucaoMensal) {
                Row linha = evolucao.createRow(row++);
                linha.createCell(0).setCellValue(mc.mes);
                linha.createCell(1).setCellValue(mc.sangue);
                linha.createCell(2).setCellValue(mc.medula);
                linha.createCell(3).setCellValue(mc.leite);
                linha.createCell(4).setCellValue(mc.total);
            }
            autoAjustar(evolucao, 5);

            wb.write(out);
            return out.toByteArray();
        }
    }

    private CellStyle estiloTitulo(Workbook wb) {
        CellStyle st = wb.createCellStyle();
        Font f = wb.createFont();
        f.setBold(true);
        f.setFontHeightInPoints((short) 14);
        st.setFont(f);
        return st;
    }

    private CellStyle estiloCabecalho(Workbook wb) {
        CellStyle st = wb.createCellStyle();
        Font f = wb.createFont();
        f.setBold(true);
        st.setFont(f);
        st.setFillForegroundColor(IndexedColors.ROSE.getIndex());
        st.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        return st;
    }

    private int escreverTitulo(Sheet sheet, CellStyle style, int row, String texto) {
        Row r = sheet.createRow(row);
        Cell c = r.createCell(0);
        c.setCellValue(texto);
        c.setCellStyle(style);
        return row + 1;
    }

    private int escreverCabecalho(Sheet sheet, CellStyle style, int row, String... colunas) {
        Row r = sheet.createRow(row);
        for (int i = 0; i < colunas.length; i++) {
            Cell c = r.createCell(i);
            c.setCellValue(colunas[i]);
            c.setCellStyle(style);
        }
        return row + 1;
    }

    private int escreverLinha(Sheet sheet, int row, String label, Object valor) {
        Row r = sheet.createRow(row);
        r.createCell(0).setCellValue(label);
        Cell c = r.createCell(1);
        if (valor instanceof Long l) c.setCellValue(l);
        else if (valor instanceof Integer i) c.setCellValue(i);
        else c.setCellValue(String.valueOf(valor));
        return row + 1;
    }

    private int escreverLinhaPercentual(Sheet sheet, CellStyle style, int row, String label, double valor) {
        Row r = sheet.createRow(row);
        r.createCell(0).setCellValue(label);
        Cell c = r.createCell(1);
        c.setCellValue(valor);
        c.setCellStyle(style);
        return row + 1;
    }

    private void autoAjustar(Sheet sheet, int colunas) {
        for (int i = 0; i < colunas; i++) sheet.autoSizeColumn(i);
    }

    // ═══════════════════════════════════════════════════════════════════════
    // EXPORTAÇÃO — CSV
    // ═══════════════════════════════════════════════════════════════════════

    public String gerarCsv(RelatorioIndicadores r) {
        StringBuilder sb = new StringBuilder();
        sb.append("\uFEFF"); // BOM para o Excel abrir acentuação corretamente

        sb.append("RELATORIO EXECUTIVO - FLUXO VITAL\n");
        sb.append("Gerado em;").append(r.geradoEm).append("\n\n");

        sb.append("RESUMO GERAL\n");
        sb.append("Indicador;Valor\n");
        sb.append("Formularios de Sangue;").append(r.totalSangue).append("\n");
        sb.append("Cadastros de Medula;").append(r.totalMedula).append("\n");
        sb.append("Doacoes de Leite;").append(r.totalLeite).append("\n");
        sb.append("Total Geral de Doacoes;").append(r.totalGeral).append("\n");
        sb.append("Instituicoes Parceiras;").append(r.totalInstituicoes).append("\n");
        sb.append("Doacoes Realizadas;").append(r.totalRealizadas).append("\n");
        sb.append("Taxa de Conversao (%);").append(r.taxaConversao).append("\n");
        sb.append("Taxa de Cancelamento (%);").append(r.taxaCancelamento).append("\n");
        sb.append("Taxa de Pendencia (%);").append(r.taxaPendencia).append("\n\n");

        sb.append("STATUS POR TIPO\n");
        sb.append("Status;Sangue;Medula;Leite;Total\n");
        for (String chave : List.of("pendente", "confirmado", "cancelado", "realizado")) {
            long s = r.statusSangue.getOrDefault(chave, 0L);
            long m = r.statusMedula.getOrDefault(chave, 0L);
            long l = r.statusLeite.getOrDefault(chave, 0L);
            sb.append(capitalizar(chave)).append(";").append(s).append(";").append(m).append(";").append(l)
              .append(";").append(s + m + l).append("\n");
        }
        sb.append("\n");

        sb.append("INSTITUICOES POR CATEGORIA\n");
        sb.append("Categoria;Quantidade\n");
        for (Map.Entry<String, Long> e : r.instituicoesPorCategoria.entrySet()) {
            sb.append(e.getKey()).append(";").append(e.getValue()).append("\n");
        }
        sb.append("\n");

        sb.append("INSTITUICOES POR ESTADO\n");
        sb.append("Estado;Quantidade\n");
        for (RelatorioIndicadores.EstadoContagem ec : r.instituicoesPorEstado) {
            sb.append(ec.estado).append(";").append(ec.total).append("\n");
        }
        sb.append("\n");

        sb.append("EVOLUCAO MENSAL\n");
        sb.append("Mes;Sangue;Medula;Leite;Total\n");
        for (RelatorioIndicadores.MesContagem mc : r.evolucaoMensal) {
            sb.append(mc.mes).append(";").append(mc.sangue).append(";").append(mc.medula).append(";")
              .append(mc.leite).append(";").append(mc.total).append("\n");
        }

        return sb.toString();
    }
}
