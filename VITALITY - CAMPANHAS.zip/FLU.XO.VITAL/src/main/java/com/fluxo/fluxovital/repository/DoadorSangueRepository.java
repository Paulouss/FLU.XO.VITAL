package com.fluxo.fluxovital.repository;

import com.fluxo.fluxovital.model.DoadorSangue;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

public interface DoadorSangueRepository extends JpaRepository<DoadorSangue, Long> {
    List<DoadorSangue> findByDoadorIdOrderByCriadoEmDesc(Long doadorId);
    List<DoadorSangue> findAllByOrderByCriadoEmDesc();
    boolean existsByCpf(String cpf);
    long countByRg(String rg);

    // ─── Usado pelo Painel Hemomar (e por qualquer painel futuro por unidade) ─
    List<DoadorSangue> findByUnidadeOrderByDataAgendamentoAsc(String unidade);
    long countByUnidade(String unidade);
    long countByUnidadeAndStatus(String unidade, DoadorSangue.StatusTriagem status);

    // ─── Simulador do Painel Hemomar ───────────────────────────────────────────
    // @Transactional é necessário aqui: delete derivado remove entidade por
    // entidade via EntityManager.remove(), o que exige uma transação de escrita
    // ativa (diferente de save/saveAll, que já vêm transacionais por padrão).
    @Transactional
    long deleteByUnidadeAndSimuladoTrue(String unidade);
}
